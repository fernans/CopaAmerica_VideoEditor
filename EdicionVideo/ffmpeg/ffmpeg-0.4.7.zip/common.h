#ifndef FFMPEG_COMMON_H
#define FFMPEG_COMMON_H

#define FFMPEG_VERSION_INT 0x000406
#define FFMPEG_VERSION     "0.4.6"

#endif /* COMMON_H */
