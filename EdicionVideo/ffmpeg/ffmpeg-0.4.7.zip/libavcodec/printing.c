/*
 * printing.c, supplies common print routines for openh323.
 *
 * Copyright (c) 2003 Derek J Smithies
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include "common.h"
#include "avcodec.h"

void (*avcodec_fprintf_fn)(char *) = NULL;
 
#include <stdarg.h>
 

int openh323_printf(const char * str, ...)
{
  if (avcodec_fprintf_fn != NULL) {
    char buffer[1024];
    va_list args;
    va_start(args, str);
    vsprintf(buffer, str, args);
    (*avcodec_fprintf_fn)(buffer);
  }
  return 0;
}
 
int openh323_fprintf(FILE * file, const char * str, ...)
{
  if (avcodec_fprintf_fn != NULL) {
    char buffer[1024];
    va_list args;
    va_start(args, str);
    vsprintf(buffer, str, args);
    (*avcodec_fprintf_fn)(buffer);
  }
  return 0;
}
 
void avcodec_set_print_fn(void (* print_fn)(char *))
{
  avcodec_fprintf_fn = print_fn;
}

