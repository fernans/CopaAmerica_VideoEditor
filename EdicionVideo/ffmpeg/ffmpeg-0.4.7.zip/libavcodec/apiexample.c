/**
 * @file apiexample.c
 * avcodec API use example.
 *
 * Note that this library only handles codecs (mpeg, mpeg4, etc...),
 * not file formats (avi, vob, etc...). See library 'libav' for the
 * format handling 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <windows.h> 

#ifdef HAVE_AV_CONFIG_H
#undef HAVE_AV_CONFIG_H
#endif

#include "avcodec.h"

////////////////////////////////////////////////////////////////////

typedef unsigned short uint16_t;
typedef signed short int16_t;
typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef unsigned __int64 uint64_t;
typedef signed char int8_t;
typedef signed int int32_t;
typedef signed __int64 int64_t;

#    ifndef __MINGW32__
#        define int64_t_C(c)     (c ## i64)
#        define uint64_t_C(c)    (c ## i64)

#        define inline __inline

#    else
#        define int64_t_C(c)     (c ## LL)
#        define uint64_t_C(c)    (c ## ULL)
#    endif /* __MINGW32__ */

#    ifdef _DEBUG
#        define DEBUG
#    endif

#    define snprintf _snprintf
#    define vsnprintf _vsnprintf

typedef struct PutBitContext {
#ifdef ALT_BITSTREAM_WRITER
    uint8_t *buf, *buf_end;
    int index;
#else
    uint32_t bit_buf;
    int bit_left;
    uint8_t *buf, *buf_ptr, *buf_end;
#endif
    int64_t data_out_size; /* in bytes */
} PutBitContext;

int64_t get_bit_count(PutBitContext *s); /* XXX: change function name */

typedef struct GetBitContext {
    const uint8_t *buffer, *buffer_end;
#ifdef ALT_BITSTREAM_READER
    int index;
#elif defined LIBMPEG2_BITSTREAM_READER
    uint8_t *buffer_ptr;
    uint32_t cache;
    int bit_count;
#elif defined A32_BITSTREAM_READER
    uint32_t *buffer_ptr;
    uint32_t cache0;
    uint32_t cache1;
    int bit_count;
#endif
    int size_in_bits;
} GetBitContext;

static inline int get_bits_count(GetBitContext *s);

#define VLC_TYPE int16_t

typedef struct VLC {
    int bits;
    VLC_TYPE (*table)[2]; ///< code, bits
    int table_size, table_allocated;
} VLC;

typedef struct RL_VLC_ELEM {
    int16_t level;
    int8_t len;
    uint8_t run;
} RL_VLC_ELEM;

#include "mpegvideo.h"

////////////////////////////////////////////////////////////////////

AVCodec h263_encoder = {
    "h263",
    CODEC_TYPE_VIDEO,
    CODEC_ID_H263,
    sizeof(MpegEncContext),
    MPV_encode_init,
    MPV_encode_picture,
    MPV_encode_end,
};

AVCodec h263p_encoder = {
    "h263p",
    CODEC_TYPE_VIDEO,
    CODEC_ID_H263P,
    sizeof(MpegEncContext),
    MPV_encode_init,
    MPV_encode_picture,
    MPV_encode_end,
};

AVCodec h263_decoder = {
    "h263",
    CODEC_TYPE_VIDEO,
    CODEC_ID_H263,
    sizeof(MpegEncContext),
    ff_h263_decode_init,
    NULL,
    ff_h263_decode_end,
    ff_h263_decode_frame,
    CODEC_CAP_DRAW_HORIZ_BAND | CODEC_CAP_DR1 | CODEC_CAP_TRUNCATED,
    NULL,
    NULL,
    ff_mpeg_flush,
};

////////////////////////////////////////////////////////////////////

#define INBUF_SIZE 4096

void rtp_callback_rfc2190_A(void *data, int size, void *priv_data,
          int pb, int sbit, int ebit, int src, int inter,
          int umv, int sac, int ap, int dbq, int trb, int tr){
    AVCodecContext *c = (AVCodecContext *) priv_data;
    MpegEncContext *s = (MpegEncContext *) c->priv_data;

    printf("video packet of %d bytes (0x%.8lX to 0x%.8lX, [%.2hhX %.2hhX %.2hhX %.2hhX %.2hhX ...]), {%.2d,%.2d} ->{%.2d,%.2d}\n",
           size, (unsigned long)data, (unsigned long)data + size - 1,
           ((unsigned char *)data)[0], ((unsigned char *)data)[1],
           ((unsigned char *)data)[2], ((unsigned char *)data)[3], ((unsigned char *)data)[4],
           s->rtp_last_mb_x, s->rtp_last_mb_y, s->mb_x, s->mb_y);
    fflush(stdout);
}

void rtp_callback_rfc2190_B(void *data, int size, void *priv_data,
          int pb, int sbit, int ebit, int src, int quant, int gobn, int mba, int inter,
          int umv, int sac, int ap, int hmv1, int vmv1, int hmv2, int vmv2){
    AVCodecContext *c = (AVCodecContext *) priv_data;
    MpegEncContext *s = (MpegEncContext *) c->priv_data;

    printf("video packet of %d bytes (0x%.8lX to 0x%.8lX, [%.2hhX %.2hhX %.2hhX %.2hhX %.2hhX ...]), {%.2d,%.2d} ->{%.2d,%.2d}\n",
           size, (unsigned long)data, (unsigned long)data + size - 1,
           ((unsigned char *)data)[0], ((unsigned char *)data)[1],
           ((unsigned char *)data)[2], ((unsigned char *)data)[3], ((unsigned char *)data)[4],
           s->rtp_last_mb_x, s->rtp_last_mb_y, s->mb_x, s->mb_y);
    fflush(stdout);
}

/*
// See info at: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dndllpro/html/dlldynamic.asp
typedef void (CALLBACK* TYPE_avcodec_init)(void);
typedef void (CALLBACK* TYPE_register_avcodec)(AVCodec *format);
typedef AVCodec * (CALLBACK* TYPE_avcodec_find_encoder)(enum CodecID id);
typedef AVCodec * (CALLBACK* TYPE_avcodec_find_decoder)(enum CodecID id);
typedef AVCodecContext * (CALLBACK* TYPE_avcodec_alloc_context)(void);
typedef AVFrame * (CALLBACK* TYPE_avcodec_alloc_frame)(void);
typedef int (CALLBACK* TYPE_avcodec_open)(AVCodecContext *avctx, AVCodec *codec);
typedef int (CALLBACK* TYPE_avcodec_close)(AVCodecContext *avctx);
typedef int (CALLBACK* TYPE_avcodec_encode_video)(AVCodecContext *avctx,
                                                  uint8_t *buf, int buf_size, const AVFrame *pict);
typedef int (CALLBACK* TYPE_avcodec_decode_video)(AVCodecContext *avctx, AVFrame *pict,
                                                  int *got_picture_ptr, uint8_t *buf, int buf_size);

TYPE_avcodec_init avcodec_init;
TYPE_register_avcodec register_avcodec;
TYPE_avcodec_find_encoder avcodec_find_encoder;
TYPE_avcodec_find_decoder avcodec_find_decoder;
TYPE_avcodec_alloc_context avcodec_alloc_context;
TYPE_avcodec_alloc_frame avcodec_alloc_frame;
TYPE_avcodec_open avcodec_open;
TYPE_avcodec_close avcodec_close;
TYPE_avcodec_encode_video avcodec_encode_video;
TYPE_avcodec_decode_video avcodec_decode_video;

AVCodec *h263_encoder;
AVCodec *h263p_encoder;
AVCodec *h263_decoder;
*/

////////////////////////////////////////////////////////////////////

/*
 * Video encoding example 
 */
void video_encode_example(const char *filename)
{
    AVCodec *codec;
    AVCodecContext *c;
    AVFrame *pic;
    uint8_t *picbuf, *outbuf;
    int i, x, y, picbuf_size, outbuf_size, out_size;
    FILE *f;

    printf("video_encode_example(%s) :\n", filename);
    fflush(stdout);

    // find the video encoder
    codec = avcodec_find_encoder(CODEC_ID_H263);
    if (!codec) {
        fprintf(stderr, "codec not found\n");
        exit(1);
    }

    printf("found codec @ 0x%.8X\n", codec);
    fflush(stdout);

    c = avcodec_alloc_context();
    if (!c) {
        fprintf(stderr, "context not allocated\n");
        exit(1);
    }

    pic = avcodec_alloc_frame();
    if (!pic) {
        fprintf(stderr, "frame not allocated\n");
        exit(1);
    }

    // private data
    c->opaque = c;

    // put sample parameters
    c->bit_rate = 150000;
    c->bit_rate_tolerance = c->bit_rate << 3;
    c->rc_min_rate = 0;
    c->rc_max_rate = c->bit_rate << 1;
    c->qmin = 2;
    c->qmax = 20;    

    // resolution (must be a multiple of two)
    c->width = 352;
    c->height = 288;

    // frames per second
    c->frame_rate = 25;  
    c->frame_rate_base = 1;

    c->gop_size = 10; // emit one intra frame every ten frames
    c->max_b_frames = 0; // no B frames

    c->rtp_payload_size = 750; 
    c->rtp_mode = 1;
    c->rtp_callback_rfc2190_A = rtp_callback_rfc2190_A;
    c->rtp_callback_rfc2190_B = rtp_callback_rfc2190_B;

    // open it
    if (avcodec_open(c, codec) < 0) {
        fprintf(stderr, "could not open codec\n");
        exit(1);
    }

    printf("opened codec\n");
    fflush(stdout);

    // the codec gives us the frame size, in samples

    // alloc image and output buffer
    outbuf_size = c->width * c->height;
    outbuf = malloc(outbuf_size);

    printf("outbuf malloc'ed @ 0x%.8lX\n", (unsigned long)outbuf);
    fflush(stdout);

    printf("video_encode_example(%s) :\n", filename);
    fflush(stdout);

    picbuf_size = c->width * c->height;
    picbuf = malloc((picbuf_size * 3) / 2); // size for YUV 420
    
    pic->data[0] = picbuf;
    pic->data[1] = pic->data[0] + picbuf_size;
    pic->data[2] = pic->data[1] + picbuf_size / 4;
    pic->linesize[0] = c->width;
    pic->linesize[1] = c->width / 2;
    pic->linesize[2] = c->width / 2;

    printf("picbuf malloc'ed @ 0x%.8lX (0x%.8lX, 0x%.8lX)\n", (unsigned long)picbuf, (unsigned long)pic->data[1], (unsigned long)pic->data[2]);
    fflush(stdout);

    printf("video_encode_example(%s) :\n", filename);
    fflush(stdout);

exit(1);

    f = fopen(filename, "w");
    if (!f) {
        fprintf(stderr, "could not open %s\n", filename);
        exit(1);
    }
    
    printf("file open for writing\n");
    fflush(stdout);

    // encode 5 frames of video
    for(i=0;i<5;i++) {
        // prepare a dummy image
        // Y
        for(y=0;y<c->height;y++) {
            for(x=0;x<c->width;x++) {
                pic->data[0][y * pic->linesize[0] + x] = x + y + i * 3;
            }
        }

        // Cb and Cr
        for(y=0;y<c->height/2;y++) {
            for(x=0;x<c->width/2;x++) {
                pic->data[1][y * pic->linesize[1] + x] = 128 + y + i * 2;
                pic->data[2][y * pic->linesize[2] + x] = 64 + x + i * 5;
            }
        }

        printf("created (dummy) frame %3d\n", i);
        fflush(stdout);

        // encode the image
        out_size = avcodec_encode_video(c, outbuf, outbuf_size, pic);

//    printf("outbuf malloc'ed @ 0x%.8lX\n", (unsigned long)outbuf);
//    fflush(stdout);

        printf("encoded frame %3d (size=%5d)\n", i, out_size);
        fflush(stdout);

//    printf("outbuf malloc'ed @ 0x%.8lX\n", (unsigned long)outbuf);
//    fflush(stdout);

        fwrite(outbuf, 1, out_size, f);

//    printf("outbuf malloc'ed @ 0x%.8lX\n", (unsigned long)outbuf);
//    fflush(stdout);

    }

    // get the delayed frames
    for(; out_size; i++) {
        out_size = avcodec_encode_video(c, outbuf, outbuf_size, NULL);
        printf("encoded frame %3d (size=%5d)\n", i, out_size);
        fflush(stdout);
        fwrite(outbuf, 1, out_size, f);
    }

    fclose(f);
    free(picbuf);
    free(outbuf);

    avcodec_close(c);

    free(c);
    free(pic);
}

/*
 * Video decoding example 
 */

void pgm_save(unsigned char *buf,int wrap, int xsize,int ysize,char *filename) 
{
    FILE *f;
    int i;

    f=fopen(filename,"w");
    fprintf(f,"P5\n%d %d\n%d\n",xsize,ysize,255);
    for(i=0;i<ysize;i++)
        fwrite(buf + i * wrap,1,xsize,f);
    fclose(f);
}

void video_decode_example(const char *outfilename, const char *filename)
{
    AVCodec *codec;
    AVCodecContext *c= NULL;
    int frame, size, got_picture, len;
    FILE *f;
    AVFrame *picture;
    uint8_t inbuf[INBUF_SIZE + FF_INPUT_BUFFER_PADDING_SIZE], *inbuf_ptr;
    char buf[1024];

    printf("video_decode_example(%s, %s) :\n", outfilename, filename);
    fflush(stdout);

    /* set end of buffer to 0 (this ensures that no overreading happens for damaged mpeg streams) */
    memset(inbuf + INBUF_SIZE, 0, FF_INPUT_BUFFER_PADDING_SIZE);

    /* find the video decoder */
    codec = avcodec_find_decoder(CODEC_ID_H263);
    if (!codec) {
        fprintf(stderr, "codec not found\n");
        exit(1);
    }

    c= avcodec_alloc_context();
    picture= avcodec_alloc_frame();

    if(codec->capabilities&CODEC_CAP_TRUNCATED)
        c->flags|= CODEC_FLAG_TRUNCATED; /* we dont send complete frames */

    /* for some codecs, such as msmpeg4 and mpeg4, width and height
       MUST be initialized there because these info are not available
       in the bitstream */

    /* open it */
    if (avcodec_open(c, codec) < 0) {
        fprintf(stderr, "could not open codec\n");
        exit(1);
    }
    
    /* the codec gives us the frame size, in samples */

    f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "could not open %s\n", filename);
        exit(1);
    }
    
    frame = 0;
    for(;;) {
        size = fread(inbuf, 1, INBUF_SIZE, f);
        if (size == 0)
            break;

        /* NOTE1: Some codecs are stream based (mpegvideo, mpegaudio)
           and this is the only method to use them because you cannot
           know the compressed data size before analysing it. 

           BUT some other codecs (msmpeg4, mpeg4) are inherently frame
           based, so you must call them with all the data for one
           frame exactly. You must also initialize 'width' and
           'height' before initializing them. */

        /* NOTE2: some codecs allow the raw parameters (frame size,
           sample rate) to be changed at any frame. We handle this, so
           you should also take care of it */

        inbuf_ptr = inbuf;
        while (size > 0) {
            len = avcodec_decode_video(c, picture, &got_picture, 
                                         inbuf_ptr, size);
            if (len < 0) {
                fprintf(stderr, "Error while decoding frame %d\n", frame);
                exit(1);
            }
            if (got_picture) {
                printf("saving frame %3d\n", frame);
                fflush(stdout);

                /* the picture is allocated by the decoder. no need to
                   free it */
                snprintf(buf, sizeof(buf), outfilename, frame);
                pgm_save(picture->data[0], picture->linesize[0], 
                         c->width, c->height, buf);
                frame++;
            }
            size -= len;
            inbuf_ptr += len;
        }
    }

    /* some codecs, such as MPEG, transmit the I and P frame with a
       latency of one frame. You must do the following to have a
       chance to get the last frame of the video */
    len = avcodec_decode_video(c, picture, &got_picture, 
                                 NULL, 0);
    if (got_picture) {
        printf("saving last frame %3d\n", frame);
        fflush(stdout);
        
        /* the picture is allocated by the decoder. no need to
           free it */
        snprintf(buf, sizeof(buf), outfilename, frame);
        pgm_save(picture->data[0], picture->linesize[0], 
                 c->width, c->height, buf);
        frame++;
    }

    fclose(f);

    avcodec_close(c);
    free(c);
    free(picture);
}

int main(int argc, char **argv)
{
    char *filename;
/*
    HINSTANCE dllHandle;
*/

    printf("command line has %d args: %s %s ...\n", argc, argv[0], argv[1]);
    printf("starting ...\n");
    fflush(stdout);

/*
    // load the dll and keep the handle to it
    dllHandle = LoadLibrary("libavcodec.dll");
    if (NULL == dllHandle) return -1;

    printf("DLL loaded ...\n");
    fflush(stdout);

    avcodec_init = (TYPE_avcodec_init)GetProcAddress(dllHandle,"avcodec_init");
    if (NULL == avcodec_init) return -1;

    register_avcodec = (TYPE_register_avcodec)GetProcAddress(dllHandle,"register_avcodec");
    if (NULL == register_avcodec) return -1;

    avcodec_find_encoder = (TYPE_avcodec_find_encoder)GetProcAddress(dllHandle,"avcodec_find_encoder");
    if (NULL == avcodec_find_encoder) return -1;

    avcodec_find_decoder = (TYPE_avcodec_find_decoder)GetProcAddress(dllHandle,"avcodec_find_decoder");
    if (NULL == avcodec_find_decoder) return -1;

    avcodec_alloc_context = (TYPE_avcodec_alloc_context)GetProcAddress(dllHandle,"avcodec_alloc_context");
    if (NULL == avcodec_alloc_context) return -1;

    avcodec_alloc_frame = (TYPE_avcodec_alloc_frame)GetProcAddress(dllHandle,"avcodec_alloc_frame");
    if (NULL == avcodec_alloc_frame) return -1;

    avcodec_open = (TYPE_avcodec_open)GetProcAddress(dllHandle,"avcodec_open");
    if (NULL == avcodec_open) return -1;

    avcodec_close = (TYPE_avcodec_close)GetProcAddress(dllHandle,"avcodec_close");
    if (NULL == avcodec_close) return -1;

    avcodec_encode_video = (TYPE_avcodec_encode_video)GetProcAddress(dllHandle,"avcodec_encode_video");
    if (NULL == avcodec_encode_video) return -1;

    avcodec_decode_video = (TYPE_avcodec_decode_video)GetProcAddress(dllHandle,"avcodec_decode_video");
    if (NULL == avcodec_decode_video) return -1;

    h263_encoder = (AVCodec *)GetProcAddress(dllHandle,"h263_encoder");
    if (NULL == h263_encoder) return -1;

    h263p_encoder = (AVCodec *)GetProcAddress(dllHandle,"h263p_encoder");
    if (NULL == h263_encoder) return -1;

    h263_decoder = (AVCodec *)GetProcAddress(dllHandle,"h263_decoder");
    if (NULL == h263_encoder) return -1;

    printf("DLL functions/variables queried ...\n");
    fflush(stdout);
*/

    // must be called before using avcodec lib
    avcodec_init();

    // register only the codecs needed (to have smaller code)
    register_avcodec(&h263_encoder);
    register_avcodec(&h263p_encoder);
    register_avcodec(&h263_decoder);

    printf("registered codecs @ 0x%.8X, 0x%.8X, 0x%.8X\n", h263_encoder, h263p_encoder, h263_decoder);
    fflush(stdout);

    if (argc>1)
        filename = strdup(argv[1]);
    else
        filename = strdup("test.263");

    printf("encoding to file %s ...\n", filename);
    fflush(stdout);

    video_encode_example(filename);

    printf("decoding from file %s ...\n", filename);
    fflush(stdout);

    video_decode_example("test%d.pgm", filename);

    free(filename);

/*
    // free the library:
    FreeLibrary(dllHandle);       
*/

    return 0;
}
